﻿var palinDromeService = angular.module('palinDromeService', ['ngResource']);

palinDromeService.factory('palindromes',['$resource',
    function ($resource) {
        return $resource('/api/palindrome', {}, {
            query: { method: 'GET', params: {}, isArray: true }
        });
    }]);