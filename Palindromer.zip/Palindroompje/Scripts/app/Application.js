﻿var mainApp = angular.module('mainApp', ['ngRoute', 'ngAnimate', 'palinDromeControllers', 'palinDromeService']);

mainApp.config([
    '$routeProvider',
    function ($routeProvider) {
        $routeProvider.
            otherwise({
                redirectTo: '/'
            });
    }
]);

mainApp.filter('filterAndReduce', function () {
    return function (palindromes,max,query) {
        if (!query) {
            return palindromes;
        }

        var filtered = [];

        query = query.toLowerCase;

        angular.forEach(palindromes, function (palindrome) {
            if (palindrome.Text.toLowerCase().indexOf(query) !== -1) {
                filtered.push(palindrome);
            }
        });

        return filtered.slice(0, count);
    };
});