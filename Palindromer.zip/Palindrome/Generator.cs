﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome
{
    public class Generator
    {
                
        public Generator(int max) {
            Min = 1;
            Max = max;
        }

        private int Min { get; set; }
        private int Max { get; set; }
        private string[] Characters = new string[] { "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z" };

        public string Palindroom() {

            StringBuilder sResult = new StringBuilder(Max);
            Random rnd = new Random();
            for (int i = 0; i < (int)Math.Ceiling((double)Max/2); i++){
                int nmbr = rnd.Next(0, 25);
                sResult.Append(Characters[nmbr]);
            }
            for (int i = Max / 2 - 1; i >= 0; i--)
            {
                sResult.Append(sResult[i]);
            }
            
            return sResult.ToString();
        }

    }
}
