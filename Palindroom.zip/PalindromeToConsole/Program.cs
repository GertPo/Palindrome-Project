﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Palindrome;

namespace PalindromeToConsole
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Geef de maximale lengte van de te genereren Palindromen aan");
            string inp = Console.ReadLine();
            int nm = Convert.ToInt16(inp);
            Console.WriteLine("");
            Console.WriteLine("Geef het maximale aantal resultaten op");
            string mx = Console.ReadLine();
            int Max = Convert.ToInt16(mx);
            Console.WriteLine("");

            for (int i = 0; i < Max; i++)
            {
                Generator G = new Generator(nm);
                Console.WriteLine(G.Palindroom());
                Console.ReadLine();
            }
            


        }
    }
}
