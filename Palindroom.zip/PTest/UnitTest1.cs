﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Palindrome;

namespace PTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Generator G = new Generator(10);
            Console.Write(G.Palindroom());
        }
    }
}
