﻿var palinDromeService = angular.module('palinDromeService', ['ngResource']);

palinDromeService.factory('Dromes',['$resource',
    function ($resource) {
        return $resource('palins.json', {},{
            query: { method: 'GET',params:{},isArray:true}
        });
    }]);