﻿var palinDromeControllers = angular.module('palinDromeControllers', []);

palinDromeControllers.controller('palinDromeController', ['$scope','$http','palindromes', function ($scope, $http,palindromes) {
    var dromes = [];
    palindromes.query(function (dromes) {
        
        angular.forEach(palindromes, function (palindrome) {
            dromes.push(palindrome);
        });

        $scope.palindromes = dromes;

    });
}]);

