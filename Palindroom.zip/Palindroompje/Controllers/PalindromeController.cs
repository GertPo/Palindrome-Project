﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Palindrome;
using Palindroompje.Models;
using System.Text;

namespace Palindroompje.Controllers
{
    public class PalindromeController : ApiController
    {
        // GET: api/palindrome
        public IEnumerable<string> Get(int max,int query)
        {
            //int max = 20;
            string[] arr = new string[max];
            for (int i = 0; i < max; i++)
            {
                Generator G = new Generator(query);
                arr[i] = G.Palindroom().ToString();
                Thread.Sleep(50);
            }
                return arr;
        }

        
    }
}
